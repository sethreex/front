<script setup lang="ts">
</script>
<template>
  <nav class="navbar is-spaced is-light mb-5" role="navigation" aria-label="main navigation">
    <div class="navbar-brand">
      <a class="navbar-item" href="/">
        <img src="/logo.png" alt="CRM">
      </a>
      <a role="button" class="navbar-burger" aria-label="menu" aria-expanded="false" data-target="navbarBasicExample">
        <span aria-hidden="true"></span>
        <span aria-hidden="true"></span>
        <span aria-hidden="true"></span>
        <span aria-hidden="true"></span>
      </a>
    </div>

    <div class="navbar-menu">
      <div class="navbar-start is-hidden is-display-block-touch">
        <div class="navbar-item has-dropdown is-hoverable">
          <a class="navbar-link">Учебный процесс</a>
          <div class="navbar-dropdown">
            <a class="navbar-item">Учебная нагрузка</a>
            <a class="navbar-item">Расписание</a>
            <a class="navbar-item">Ведомости</a>
          </div>
        </div>
        <a class="navbar-item">Рейтинг</a>
        <a class="navbar-item">Эффективный контракт</a>
        <div class="navbar-item has-dropdown is-hoverable">
          <a class="navbar-link">Профессиональная деятельность</a>
          <div class="navbar-dropdown">
            <a class="navbar-item">Компетенции</a>
            <a class="navbar-item">Воспитательная работа</a>
            <a class="navbar-item">Список публикаций</a>
          </div>
        </div>
        <div class="navbar-item has-dropdown is-hoverable">
          <a class="navbar-link">Финансовая информация</a>
          <div class="navbar-dropdown">
            <a class="navbar-item">Выплаты</a>
          </div>
        </div>
        <div class="navbar-item has-dropdown is-hoverable">
          <a class="navbar-link">Информация</a>
          <div class="navbar-dropdown">
            <a class="navbar-item">Уведомления</a>
            <a class="navbar-item">Мероприятия</a>
            <a class="navbar-item">Новости</a>
          </div>
        </div>
        <a class="navbar-item">Сервисы</a>
      </div>
      <div class="navbar-end">
        <div class="navbar-item has-dropdown is-hoverable">
          <a class="navbar-link">Профиль</a>
          <div class="navbar-dropdown is-right">
            <a class="navbar-item">Редактировать</a>
            <hr class="navbar-divider">
            <a class="navbar-item">Выйти</a>
          </div>
        </div>
      </div>
    </div>
  </nav>
  <div class="container is-fluid">
    <div class="columns">
      <aside class="column is-one-quarter menu is-hidden-touch">
        <ul class="menu-list">
          <li><a>Профиль</a></li>
          <li>
            <a class="is-active">Учебный процесс</a>
            <ul>
              <li><a>Учебная нагрузка</a></li>
              <li><a>Расписание</a></li>
              <li><a>Ведомости</a></li>
            </ul>
          </li>
          <li><a>Рейтинг</a></li>
          <li><a>Эффективный контракт</a></li>
          <li>
            <a>Профессиональная деятельность</a>
            <ul>
              <li><a>Компетенции</a></li>
              <li><a>Воспитательная работа</a></li>
              <li><a>Список публикаций</a></li>
            </ul>
          </li>
          <li>
            <a>Финансовая информация</a>
            <ul>
              <li><a>Выплаты</a></li>
            </ul>
          </li>
          <li>
            <a>Информация</a>
            <ul>
              <li><a>Уведомления</a></li>
              <li><a>Мероприятия</a></li>
              <li><a>Новости</a></li>
            </ul>
          </li>
          <li><a>Сервисы</a></li>
        </ul>
      </aside>
      <div class="column">
        <Suspense>
          <RouterView />
        </Suspense>
      </div>
    </div>
  </div>
</template>
