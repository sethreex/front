import axios from 'axios'
import { getToken } from '../oidc'

const baseURL = import.meta.env.VITE_BASE_URL

export const api = axios.create({
  baseURL,
  withCredentials: true,
})

api.interceptors.request.use(async (config) => {
  const token = await getToken()
  if (token) {
    config.headers.Authorization = `Bearer ${token}`
  }
  return config
})
