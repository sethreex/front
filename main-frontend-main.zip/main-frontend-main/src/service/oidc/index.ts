import { UserManager, WebStorageStateStore, type UserManagerSettings } from 'oidc-client-ts'

const oidcConfig: UserManagerSettings = {
  authority: import.meta.env.VITE_AUTHORITY,
  client_id: import.meta.env.VITE_CLIENT_ID,
  redirect_uri: `${window.location.origin}/callback`,
  post_logout_redirect_uri: window.location.origin,
  response_type: 'code',
  scope: 'openid profile email roles',
  userStore: new WebStorageStateStore({ store: window.localStorage }),
  loadUserInfo: true,
  automaticSilentRenew: true,
  filterProtocolClaims: true,
  redirectMethod: 'replace',
  monitorSession: true,
  fetchRequestCredentials: 'omit',
  metadata: {
    issuer: "https://id.cchgeu.ru/auth/realms/main-auth",
    authorization_endpoint: "https://id.cchgeu.ru/auth/realms/main-auth/protocol/openid-connect/auth",
    token_endpoint: `${window.location.origin}/auth/realms/main-auth/protocol/openid-connect/token`,
    introspection_endpoint: "https://id.cchgeu.ru/auth/realms/main-auth/protocol/openid-connect/token/introspect",
    userinfo_endpoint: `${window.location.origin}/auth/realms/main-auth/protocol/openid-connect/userinfo`,
    end_session_endpoint: `${window.location.origin}/auth/realms/main-auth/protocol/openid-connect/logout`,
    jwks_uri: "https://id.cchgeu.ru/auth/realms/main-auth/protocol/openid-connect/certs",
    check_session_iframe: "https://id.cchgeu.ru/auth/realms/main-auth/protocol/openid-connect/login-status-iframe.html",
    grant_types_supported: [
      "authorization_code",
      "implicit",
      "refresh_token",
      "password",
      "client_credentials"
    ],
    response_types_supported: [
      "code",
      "none",
      "id_token",
      "token",
      "id_token token",
      "code id_token",
      "code token",
      "code id_token token"
    ],
    subject_types_supported: [
      "public",
      "pairwise"
    ],
    request_object_signing_alg_values_supported: [
      "PS384",
      "ES384",
      "RS384",
      "HS256",
      "HS512",
      "ES256",
      "RS256",
      "HS384",
      "ES512",
      "PS256",
      "PS512",
      "RS512",
      "none"
    ],
    response_modes_supported: [
      "query",
      "fragment",
      "form_post"
    ],
    registration_endpoint: "https://id.cchgeu.ru/auth/realms/main-auth/clients-registrations/openid-connect",
    token_endpoint_auth_methods_supported: [
      "private_key_jwt",
      "client_secret_basic",
      "client_secret_post",
      "tls_client_auth",
      "client_secret_jwt"
    ],
    token_endpoint_auth_signing_alg_values_supported: [
      "PS384",
      "ES384",
      "RS384",
      "HS256",
      "HS512",
      "ES256",
      "RS256",
      "HS384",
      "ES512",
      "PS256",
      "PS512",
      "RS512"
    ],
    claims_supported: [
      "aud",
      "sub",
      "iss",
      "auth_time",
      "name",
      "given_name",
      "family_name",
      "preferred_username",
      "email",
      "acr"
    ],
    claim_types_supported: [
      "normal"
    ],
    claims_parameter_supported: true,
    scopes_supported: [
      "openid",
      "address",
      "email",
      "microprofile-jwt",
      "offline_access",
      "phone",
      "profile",
      "roles",
      "web-origins"
    ],
    code_challenge_methods_supported: [
      "plain",
      "S256"
    ],
    revocation_endpoint: `${window.location.origin}/auth/realms/main-auth/protocol/openid-connect/revoke`,
    backchannel_logout_supported: true,
    backchannel_logout_session_supported: true
  }
};

export const authManager = new UserManager(oidcConfig);

export const getToken = async () => {
  let user = await authManager.getUser();

  if (!user) return undefined;

  if (user.expired) {
    user = await authManager.signinSilent();
  }

  return user?.access_token;
}
