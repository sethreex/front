<template>
  <button @click="authManager.signinRedirect()">Login</button>
</template>

<script setup lang="ts">
import { authManager } from '@/service/oidc'
</script>
