<template>
  <div>
    <h1>AdminPage</h1>

    <div v-if="userRoles.includes('super-admin')">Секция для супер админов</div>

    <button @click="authManager.signoutRedirect()"></button>
  </div>
</template>

<script setup lang="ts">
import { authManager } from '@/service/oidc'

const user = await authManager.getUser()
const userRoles = user!.profile.roles as string[]
</script>
