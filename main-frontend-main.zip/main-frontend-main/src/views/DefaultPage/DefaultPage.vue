<template>
  <RouterLink v-if="!canUser" to="/login">Go to login page</RouterLink>
  <template v-else>
    <RouterLink to="/admin">Admin</RouterLink>
  </template>
</template>

<script setup lang="ts">
import { authManager } from '@/service/oidc'

const canUser = await authManager.getUser()
</script>
