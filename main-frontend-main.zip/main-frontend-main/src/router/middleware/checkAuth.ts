import type { NavigationGuardNext, RouteLocationNormalized } from 'vue-router'
import { authManager } from '@/service/oidc'

export async function checkAuth(
  to: RouteLocationNormalized,
  _from: RouteLocationNormalized,
  next: NavigationGuardNext,
): Promise<void> {
  const user = await authManager.getUser()
  console.log(user);
  if (to.meta.requiresAuth && !user) {
    await authManager.signinRedirect();
  } else next()
}
