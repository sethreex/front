import { authManager } from '@/service/oidc'
import type { NavigationGuardNext, RouteLocationNormalized } from 'vue-router'

export async function checkCallback(
  to: RouteLocationNormalized,
  _from: RouteLocationNormalized,
  next: NavigationGuardNext,
): Promise<void> {
  const user = await authManager.getUser()

  if (to.path === '/callback') {
    if (to.query.code) {
      await authManager.signinCallback()
    }

    next({ path: '/' })
  } else if (to.path !== '/callback') {
    if (user && user.expired) {
      await authManager.signinRedirect()
    }

    next()
  }
}
