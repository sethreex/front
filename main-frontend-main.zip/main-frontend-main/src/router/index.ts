import { createRouter, createWebHistory } from 'vue-router'
import { checkCallback } from './middleware/checkCallback'
import { checkAuth } from './middleware/checkAuth'

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: [
    {
      path: '/admin',
      name: 'admin',
      component: () => import('@/views/AdminPage/AdminPage.vue'),
      meta: {
        requiresAuth: true,
        requiredRoles: ['super-admin'],
      },
    },
    {
      path: '/login',
      name: 'login',
      component: () => import('@/views/LoginPage/LoginPage.vue'),
    },
    {
      path: '/',
      name: 'home',
      component: () => import('@/views/DefaultPage/DefaultPage.vue'),
      meta: {
        requiresAuth: true,
      },
    },
  ],
})

router.beforeEach(checkCallback)
router.beforeEach(checkAuth)
router.beforeEach((to) => {
  const {title} = to.meta;
  if (title) document.title = `${title} | Личный кабинет`
  else document.title = 'Личный кабинет'
})

export default router
