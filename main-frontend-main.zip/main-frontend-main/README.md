# Личный кабинет ППС.

Написано на Vue3 с Vite.

## Рекомендация от разрабов этой связки

[VSCode](https://code.visualstudio.com/) + [Volar](https://marketplace.visualstudio.com/items?itemName=Vue.volar) (и отключить Vetur).

## Настройки проекта

```sh
npm install
```

### Компиляция и горячая перезагрузка для дева

```sh
npm run dev
```

### Проверка типов, компиляция и минификация для прода

```sh
npm run build
```

### Анализ кода с [ESLint](https://eslint.org/)

```sh
npm run lint
```

## ПРИМЕЧАНИЕ!!!!!!!!
Т.к. авторизация идет через древне-греческий Keycloak12, на проде есть костыль, чтобы обойти ошибку CORS. Соответственно урлы приложения не должны пересекаться с `/auth/realms/` из-за костыля в виде прокси.