from os.path import dirname, basename, isfile, join
import glob
from importlib import import_module

from fastapi import FastAPI

app = FastAPI(root_path='/api')

modules = glob.glob(join(dirname(__file__), "endpoints/*.py"))
for f in modules:
    if isfile(f) and not f.endswith('__init__.py'):
        module = import_module('endpoints.%s' % basename(f)[:-3])
        app.include_router(getattr(module, "router"))
