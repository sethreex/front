from typing import Annotated

from fastapi import APIRouter, Depends

from dependencies import get_current_user
from serializers import UserSerializer

router = APIRouter(tags=['schedule'], prefix='/schedule')


@router.get('/user/{user_id}')
async def schedule_user(user_id: int, current_user: Annotated[UserSerializer, Depends(get_current_user)]):
    return {'user_id': user_id}
