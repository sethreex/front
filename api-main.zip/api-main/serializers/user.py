from datetime import date

from pydantic import BaseModel


class UserSerializer(BaseModel):
    id: int
    surname: str
    name: str
    patronymic: str
    id_1c: str
    id_zkgu: str
    email: str
    birthday_date: date
    sub: str
    adgroups: list
    groups: list
    preferred_username: str
