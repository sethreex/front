import requests

from typing import Annotated

from fastapi import Depends
from fastapi import HTTPException, status
from fastapi.security import OAuth2PasswordBearer
from sqlalchemy import select

from dependencies import get_db_session
from models import Employee
from serializers import UserSerializer

oauth2_scheme = OAuth2PasswordBearer(tokenUrl='https://lk.cchgeu.ru/auth/realms/main-auth/protocol/openid-connect/token')

async def get_current_user(token: Annotated[str, Depends(oauth2_scheme)], session = Depends(get_db_session)) -> UserSerializer:
    user_from_api = requests.get(url='https://lk.cchgeu.ru/auth/realms/main-auth/protocol/openid-connect/userinfo',
                                 headers={'Authorization': 'Bearer {}'.format(token)})
    user_from_api = user_from_api.json()

    query = select(Employee.id, Employee.surname, Employee.name, Employee.patronymic, Employee.id_1c,
                   Employee.id_zkgu, Employee.email, Employee.birthday_date).where(Employee.email == user_from_api['email'])
    result = await session.execute(query)
    user = result.mappings().first()

    if not user: # если нет данных - вылетает 401 ошибка
        raise HTTPException(status_code = status.HTTP_401_UNAUTHORIZED,
                            detail = "Данного пользователя не существует в системе")
            
    # Отдаем смешанные данные от бд и от клоаки
    return UserSerializer(id=user.id, surname=user.surname, name=user.name, patronymic=user.patronymic,
                          id_1c=user.id_1c, id_zkgu=user.id_zkgu, email=user.email, birthday_date=user.birthday_date,
                          sub=user_from_api['sub'], adgroups=user_from_api['adgroups'], groups=user_from_api['groups'],
                          preferred_username=user_from_api['preferred_username'])
