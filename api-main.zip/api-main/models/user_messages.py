from sqlalchemy import VARCHAR, BigInteger, ForeignKey, DateTime
from sqlalchemy.orm import Mapped, mapped_column

from models import Base, StudentProfile


class UserMessages(Base):
    __tablename__ = "user_messages"
    id: Mapped[int] = mapped_column(primary_key=True)
    chat_id: Mapped[int] = mapped_column(BigInteger)
    id_student: Mapped[int] = mapped_column(ForeignKey("student_profile.id"))
    time: Mapped[str] = mapped_column(DateTime(timezone=True))
    button: Mapped[str] = mapped_column(VARCHAR)
