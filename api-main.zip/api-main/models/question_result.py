from sqlalchemy import ForeignKey, VARCHAR
from sqlalchemy.orm import Mapped, mapped_column

from models import Base


class QuestionResult(Base):
    __tablename__ = "question_result"
    id: Mapped[int] = mapped_column(primary_key=True)
    id_test: Mapped[int] = mapped_column(ForeignKey("take_test.id"))
    id_student: Mapped[int] = mapped_column(ForeignKey("student_profile.id"))
    id_question: Mapped[int] = mapped_column(ForeignKey("questions.id"), nullable=True)
    id_choice: Mapped[int] = mapped_column(ForeignKey("question_choice.id"), nullable=True)
    id_teacher: Mapped[int] = mapped_column(ForeignKey("employee.id"), nullable=True)
    answer: Mapped[str] = mapped_column(VARCHAR, nullable=True)
