from sqlalchemy import VARCHAR
from sqlalchemy.orm import Mapped, mapped_column

from models import Base


class UniversityStructuresElements(Base):
    __tablename__ = "university_structures_elements"
    id: Mapped[int] = mapped_column(primary_key=True)
    parent_element: Mapped[str] = mapped_column(VARCHAR)
    id_1c_parent_element: Mapped[str] = mapped_column(VARCHAR)
    department: Mapped[str] = mapped_column(VARCHAR)
    id_1c_department: Mapped[str] = mapped_column(VARCHAR)
