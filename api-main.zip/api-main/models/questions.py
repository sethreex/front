from sqlalchemy import VARCHAR, ForeignKey
from sqlalchemy.orm import Mapped, mapped_column

from models import Base


class Questions(Base):
    __tablename__ = "questions"
    id: Mapped[int] = mapped_column(primary_key=True)
    id_test: Mapped[int] = mapped_column(ForeignKey("take_test.id"))
    question: Mapped[str] = mapped_column(VARCHAR)
    id_1c_elementary_question: Mapped[str] = mapped_column(VARCHAR)
