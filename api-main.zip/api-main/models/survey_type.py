from sqlalchemy import ForeignKey
from sqlalchemy.orm import Mapped, mapped_column

from models import Base


class SurveyType(Base):
    __tablename__ = "survey_type"
    id: Mapped[int] = mapped_column(primary_key=True)
    id_test: Mapped[int] = mapped_column(ForeignKey("take_test.id"))
    id_teacher: Mapped[int] = mapped_column(ForeignKey("employee.id"))
