from sqlalchemy import VARCHAR
from sqlalchemy.orm import Mapped, mapped_column

from models import Base


class StudentGroup(Base):
    __tablename__ = "st_group"
    id: Mapped[int] = mapped_column(primary_key=True)
    group_name: Mapped[str] = mapped_column(VARCHAR)
    id_1c: Mapped[str] = mapped_column(VARCHAR)
