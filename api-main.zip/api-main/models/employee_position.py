from sqlalchemy import VARCHAR
from sqlalchemy.orm import Mapped, mapped_column

from models import Base


class EmployeePosition(Base):
    __tablename__ = "employee_position"
    id: Mapped[int] = mapped_column(primary_key=True)
    title: Mapped[str] = mapped_column(VARCHAR)
    id_1c: Mapped[str] = mapped_column(VARCHAR)
