from sqlalchemy import VARCHAR
from sqlalchemy.orm import Mapped, mapped_column

from models import Base


class Bet(Base):
    __tablename__ = 'bet'
    id: Mapped[int] = mapped_column(primary_key=True)
    title: Mapped[str] = mapped_column(VARCHAR)
    id_1c: Mapped[str] = mapped_column(VARCHAR)
