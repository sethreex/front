from sqlalchemy import VARCHAR, ForeignKey, FLOAT
from sqlalchemy.orm import Mapped, mapped_column

from models import Base


class EmployeeWorkload(Base):
    __tablename__ = "employee_workload"
    id: Mapped[int] = mapped_column(primary_key=True)
    id_employee_job_info: Mapped[int] = mapped_column(ForeignKey("employee_job_information.id"))
    discipline: Mapped[str] = mapped_column(VARCHAR)
    control_period: Mapped[str] = mapped_column(VARCHAR)
    control_type: Mapped[str] = mapped_column(VARCHAR)
    group: Mapped[str] = mapped_column(VARCHAR)
    employee_workload: Mapped[str] = mapped_column(VARCHAR)
    employee_workload_hours: Mapped[float] = mapped_column(FLOAT)
