from sqlalchemy import ForeignKey, VARCHAR, DATE
from sqlalchemy.orm import Mapped, mapped_column

from models import Base


class Information(Base):
    __tablename__ = "information"
    id: Mapped[int] = mapped_column(primary_key=True)
    title: Mapped[str] = mapped_column(VARCHAR)
    start_date: Mapped[str] = mapped_column(DATE)
    end_date: Mapped[str] = mapped_column(DATE)
    id_student: Mapped[int] = mapped_column(ForeignKey("student_profile.id"))
