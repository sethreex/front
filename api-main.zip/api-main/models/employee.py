from sqlalchemy import VARCHAR, DATE
from sqlalchemy.orm import Mapped, mapped_column

from models import Base


class Employee(Base):
    __tablename__ = "employee"
    id: Mapped[int] = mapped_column(primary_key=True)
    surname: Mapped[str] = mapped_column(VARCHAR)
    name: Mapped[str] = mapped_column(VARCHAR)
    patronymic: Mapped[str] = mapped_column(VARCHAR)
    id_1c: Mapped[str] = mapped_column(VARCHAR)
    id_zkgu: Mapped[str] = mapped_column(VARCHAR)
    email: Mapped[str] = mapped_column(VARCHAR)
    birthday_date: Mapped[str] = mapped_column(DATE)
