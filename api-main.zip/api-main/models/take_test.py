from sqlalchemy import VARCHAR, BOOLEAN, DATE
from sqlalchemy.orm import Mapped, mapped_column

from models import Base


class TakeTest(Base):
    __tablename__ = "take_test"
    id: Mapped[int] = mapped_column(primary_key=True)
    title: Mapped[str] = mapped_column(VARCHAR)  # название
    id_1c: Mapped[str] = mapped_column(VARCHAR)
    id_1c_questionnaire_template: Mapped[str] = mapped_column(VARCHAR)
    free_test: Mapped[bool] = mapped_column(BOOLEAN)
    time_test_starts: Mapped[str] = mapped_column(DATE)
    time_test_ends: Mapped[str] = mapped_column(DATE)
    test_type: Mapped[str] = mapped_column(VARCHAR)
