from sqlalchemy import VARCHAR
from sqlalchemy.orm import Mapped, mapped_column

from models import Base


class StudyPlan(Base):
    __tablename__ = "study_plan"
    id: Mapped[int] = mapped_column(primary_key=True)
    study_plan: Mapped[str] = mapped_column(VARCHAR(45))
    url_study_plan: Mapped[str] = mapped_column(VARCHAR)
    faculty: Mapped[str] = mapped_column(VARCHAR)
    specialty: Mapped[str] = mapped_column(VARCHAR)
    specialization: Mapped[str] = mapped_column(VARCHAR)
    id_1c: Mapped[str] = mapped_column(VARCHAR)
    education_form: Mapped[str] = mapped_column(VARCHAR(25))
