from sqlalchemy import ForeignKey, VARCHAR, DATE, BOOLEAN
from sqlalchemy.orm import Mapped, mapped_column

from models import Base


class ImportantInformation(Base):
    __tablename__ = "important_information"
    id: Mapped[int] = mapped_column(primary_key=True)
    title: Mapped[str] = mapped_column(VARCHAR)
    start_date: Mapped[str] = mapped_column(DATE)
    end_date: Mapped[str] = mapped_column(DATE)
    id_student: Mapped[int] = mapped_column(ForeignKey("student_profile.id"))
    send: Mapped[bool] = mapped_column(BOOLEAN)
