from sqlalchemy import VARCHAR, DATE, ForeignKey, INTEGER, TIME
from sqlalchemy.orm import Mapped, mapped_column

from models import Base


class StudentSchedule(Base):
    __tablename__ = "student_schedule"
    id: Mapped[int] = mapped_column(primary_key=True)
    numerator_denominator: Mapped[int] = mapped_column(VARCHAR)
    lesson_date: Mapped[str] = mapped_column(DATE)
    weekday: Mapped[str] = mapped_column(VARCHAR)
    subject: Mapped[str] = mapped_column(VARCHAR)
    id_teacher: Mapped[int] = mapped_column(ForeignKey("employee.id"), nullable=True)
    number_classroom: Mapped[str] = mapped_column(VARCHAR, nullable=True)
    number_subgroup: Mapped[int] = mapped_column(INTEGER, nullable=True)
    lesson_type: Mapped[str] = mapped_column(VARCHAR)
    time_lesson_starts: Mapped[str] = mapped_column(TIME)
    time_lesson_ends: Mapped[str] = mapped_column(TIME)
    id_group: Mapped[int] = mapped_column(ForeignKey("st_group.id"))
    education_form: Mapped[str] = mapped_column(VARCHAR, nullable=True)
