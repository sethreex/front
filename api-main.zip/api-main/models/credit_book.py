from sqlalchemy import VARCHAR, ForeignKey
from sqlalchemy.orm import Mapped, mapped_column

from models import Base


class CreditBook(Base):
    __tablename__ = 'credit_book'
    id: Mapped[int] = mapped_column(primary_key=True)
    number_cb: Mapped[str] = mapped_column(VARCHAR(30))
    id_student: Mapped[int] = mapped_column(ForeignKey("student_profile.id"))
    id_study_plan: Mapped[int] = mapped_column(ForeignKey("study_plan.id"))
    id_1c: Mapped[str] = mapped_column(VARCHAR)
