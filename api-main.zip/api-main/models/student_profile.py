from sqlalchemy import VARCHAR, BigInteger
from sqlalchemy.orm import Mapped, mapped_column

from models import Base


class StudentProfile(Base):
    __tablename__ = "student_profile"
    id: Mapped[int] = mapped_column(primary_key=True)
    id_chat = mapped_column(BigInteger)
    surname: Mapped[str] = mapped_column(VARCHAR(100))
    name: Mapped[str] = mapped_column(VARCHAR(100))
    patronymic: Mapped[str] = mapped_column(VARCHAR(100))
    id_1c: Mapped[str] = mapped_column(VARCHAR)