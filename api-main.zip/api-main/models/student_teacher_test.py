from sqlalchemy import ForeignKey
from sqlalchemy.orm import Mapped, mapped_column

from models import Base


class StudentTeacherTest(Base):
    __tablename__ = "student_teacher_test"
    id: Mapped[int] = mapped_column(primary_key=True)
    id_student: Mapped[int] = mapped_column(ForeignKey("student_profile.id"))
    id_test: Mapped[int] = mapped_column(ForeignKey("take_test.id"))
    id_teacher: Mapped[int] = mapped_column(ForeignKey("employee.id"), nullable=True)
