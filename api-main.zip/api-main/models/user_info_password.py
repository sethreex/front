from sqlalchemy import VARCHAR
from sqlalchemy.orm import Mapped, mapped_column

from models import Base


class UserInfoPassword(Base):
    __tablename__ = "user_info_password"
    id: Mapped[int] = mapped_column(primary_key=True)
    user_name: Mapped[str] = mapped_column(VARCHAR)
    user_pass: Mapped[str] = mapped_column(VARCHAR)
