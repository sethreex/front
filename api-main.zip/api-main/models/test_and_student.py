from sqlalchemy import BOOLEAN, ForeignKey
from sqlalchemy.orm import Mapped, mapped_column

from models import Base, StudentProfile, TakeTest


class TestAndStudent(Base):
    __tablename__ = "test_and_student"
    id: Mapped[int] = mapped_column(primary_key=True)
    id_student: Mapped[int] = mapped_column(ForeignKey("student_profile.id"))
    id_survey: Mapped[int] = mapped_column(ForeignKey("take_test.id"))
    passed: Mapped[bool] = mapped_column(BOOLEAN, nullable=True)
