from sqlalchemy import ForeignKey, VARCHAR
from sqlalchemy.orm import Mapped, mapped_column

from models import Base


class QuestionChoice(Base):
    __tablename__ = "question_choice"
    id: Mapped[int] = mapped_column(primary_key=True)
    id_question: Mapped[int] = mapped_column(ForeignKey("questions.id"))
    answer_variant: Mapped[str] = mapped_column(VARCHAR)
