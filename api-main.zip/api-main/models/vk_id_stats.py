from sqlalchemy import VARCHAR
from sqlalchemy.orm import Mapped, mapped_column

from models import Base


class VkIdStats(Base):
    __tablename__ = "vk_id_stats"
    id: Mapped[int] = mapped_column(primary_key=True)
    vk_id: Mapped[str] = mapped_column(VARCHAR)
    current_operation: Mapped[str] = mapped_column(VARCHAR)
    faculty: Mapped[str] = mapped_column(VARCHAR)
