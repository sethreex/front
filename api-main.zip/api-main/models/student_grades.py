from sqlalchemy import VARCHAR, ForeignKey
from sqlalchemy.orm import Mapped, mapped_column

from models import Base


class StudentGrades(Base):
    __tablename__ = "student_grades"
    id: Mapped[int] = mapped_column(primary_key=True)
    semestr: Mapped[str] = mapped_column(VARCHAR, nullable=True)
    id_credit_book: Mapped[int] = mapped_column(ForeignKey("credit_book.id"), nullable=True)
    subject: Mapped[str] = mapped_column(VARCHAR, nullable=True)
    study_year: Mapped[str] = mapped_column(VARCHAR, nullable=True)
    id_teacher: Mapped[int] = mapped_column(ForeignKey("employee.id"), nullable=True)
    mark: Mapped[str] = mapped_column(VARCHAR, nullable=True)
    form_control: Mapped[str] = mapped_column(VARCHAR, nullable=True)
    id_1c_document: Mapped[str] = mapped_column(VARCHAR)