from sqlalchemy import VARCHAR, ForeignKey
from sqlalchemy.orm import Mapped, mapped_column

from models import Base


class StudentArrears(Base):
    __tablename__ = "student_arrears"
    id: Mapped[int] = mapped_column(primary_key=True)
    id_student: Mapped[int] = mapped_column(ForeignKey("student_profile.id"))
    discipline: Mapped[str] = mapped_column(VARCHAR)
    period: Mapped[str] = mapped_column(VARCHAR)
    form_control: Mapped[str] = mapped_column(VARCHAR)
