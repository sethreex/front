from sqlalchemy import VARCHAR, BOOLEAN, ForeignKey
from sqlalchemy.orm import Mapped, mapped_column

from models import Base

class EmployeeJobInformation(Base):
    __tablename__ = "employee_job_information"
    id: Mapped[int] = mapped_column(primary_key=True)
    id_employee: Mapped[int] = mapped_column(ForeignKey("employee.id"))
    id_bet: Mapped[int] = mapped_column(ForeignKey("bet.id"))
    id_position: Mapped[int] = mapped_column(ForeignKey("employee_position.id"))
    employment_type: Mapped[str] = mapped_column(VARCHAR)
    id_university_structures_elements: Mapped[int] = mapped_column(ForeignKey("university_structures_elements.id"))
    employee: Mapped[bool] = mapped_column(BOOLEAN)
    id_1c: Mapped[str] = mapped_column(VARCHAR)