from sqlalchemy import ForeignKey
from sqlalchemy.orm import Mapped, mapped_column

from models import Base


class GroupAndStudent(Base):
    __tablename__ = "group_and_student"
    id: Mapped[int] = mapped_column(primary_key=True)
    id_credit_book: Mapped[int] = mapped_column(ForeignKey("credit_book.id"))
    id_group: Mapped[int] = mapped_column(ForeignKey("student_profile.id"))
